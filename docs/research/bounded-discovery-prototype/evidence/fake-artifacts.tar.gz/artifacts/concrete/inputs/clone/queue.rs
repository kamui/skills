fn idle() {}
fn wake() {}
fn outside() {}
