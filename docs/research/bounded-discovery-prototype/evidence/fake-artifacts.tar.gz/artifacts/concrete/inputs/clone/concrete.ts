type A = {a: string};
type B = {b: number};
type Pair = A & B;
