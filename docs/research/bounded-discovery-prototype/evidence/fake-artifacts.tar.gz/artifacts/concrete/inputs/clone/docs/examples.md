Synthetic example text.
